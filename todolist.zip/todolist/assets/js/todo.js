// check off specific todos by clicking
//onclick is used to apply all li when ever new li is added
//click is used for only existing li it doesnt applicable for lis.
$("ul").on("click","li",function(){
	$(this).toggleClass("completed");
});
//inside on that specifies this..here span
$("ul").on("click","span",function(event){
	//it will help to remove the entire h1
	$(this).parent().fadeOut(500,function(){
		$(this).remove();
	});
	event.stopPropagation();//this is used to stop the efeect to li because span is in lu so if we clicked span it will affect to li also
	//so if we want to remove that effect we use stopprogation();
});
$("input[type ='text'").keypress(function(event){
	if(event.which === 13){
		var todotext = $(this).val();
		//this will empty the input after todo is added
		$(this).val("");
		//add todo
		$("ul").append("<li><span><i class='fa fa-trash'></i></span> "+todotext+"</li>")
	}	
})

$(".fa-plus").click(function(){
	$("input[type='text'").fadeToggle();
})